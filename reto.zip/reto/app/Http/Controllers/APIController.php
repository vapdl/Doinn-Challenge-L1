<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Area;

class APIController extends Controller
{
    public function geolocalization($address)
    {
        $aux=$address;
        $address = str_replace(" ", "%", $address);
        $address=utf8_encode($address);
        $address=urlencode($address);
        $url = "http://maps.google.com/maps/api/geocode/json?sensor=false&address=$address";
        $response = file_get_contents($url);
        $json = json_decode($response,TRUE);
        if($json["status"]=="OK")
        {
            $latitude=$json['results'][0]['geometry']['location']['lat'];
            $longitude=$json['results'][0]['geometry']['location']['lng'];
            $point=[$latitude,$longitude];
            $area=Area::where('name','=','area 1')->get();
            $var=$this->inside($point,$area);
            if($var)
            {
                $response=array($aux=>'area 1');
            }
            else
            {
                $area=Area::where('name','=','area 2')->get();
                $var=$this->inside($point,$area);
                if($var)
                {
                    $response=array($aux=>'area 2');
                }
                else
                {
                    $response=array($aux=>'none');
                }
            }

        }
        else
        {
            $response=array($aux=>'none');
        }

        return \Response::json($response);
    }
    //-------------------------------------------------------------------------------------------------------------------
    private function inside($point, $area)
    {
        foreach($area as $item)
        {
            $polygon[]=[$item->lat,$item->lng];
        }
        $polygon[]=$polygon[0];
    if($polygon[0] != $polygon[count($polygon)-1])
        $polygon[count($polygon)] = $polygon[0];
    $j = 0;
    $oddNodes = false;
    $x = $point[1];
    $y = $point[0];
    $n = count($polygon);
    for ($i = 0; $i < $n; $i++)
    {
        $j++;
        if ($j == $n)
        {
            $j = 0;
        }
        if ((($polygon[$i][0] < $y) && ($polygon[$j][0] >= $y)) || (($polygon[$j][0] < $y) && ($polygon[$i][0] >=
                    $y)))
        {
            if ($polygon[$i][1] + ($y - $polygon[$i][0]) / ($polygon[$j][0] - $polygon[$i][0]) * ($polygon[$j][1] -
                    $polygon[$i][1]) < $x)
            {
                $oddNodes = !$oddNodes;
            }
        }
    }
    return $oddNodes;
}
}
